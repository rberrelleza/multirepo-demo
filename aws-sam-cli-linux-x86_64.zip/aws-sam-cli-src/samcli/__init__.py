"""
SAM CLI version
"""

__version__ = "1.41.0"
