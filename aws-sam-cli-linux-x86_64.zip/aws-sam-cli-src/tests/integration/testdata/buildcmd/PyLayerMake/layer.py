import numpy


def layer_method():
    return {"pi": "{0:.2f}".format(numpy.pi)}
